using System;
using System.ComponentModel;
using System.Drawing;
using System.Security.Principal;
using System.Windows.Forms;
using Microsoft.Win32;
using System;
using System.Linq;
namespace WinFormsApp1

{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string value = WindowsIdentity.GetCurrent().User.Value;
            this.textBox1.Text = value;
            this.button2.Enabled = false;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        

            
            private void button1_Click(object sender, EventArgs e)
        {
            spoofmyhwid.SpoofHWID();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            spoofmyhwid.CheckHWID();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void hide_Click(object sender, EventArgs e)
        {
            this.textBox1.PasswordChar = '*';
            this.button2.Enabled = true;
            this.hide.Enabled = false;
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.textBox1.PasswordChar = '\0';
            this.button2.Enabled = false;
            this.hide.Enabled = true;
        }
    }
}