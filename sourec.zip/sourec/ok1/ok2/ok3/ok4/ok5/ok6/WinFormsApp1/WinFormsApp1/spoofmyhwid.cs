﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Win32;
namespace WinFormsApp1
{
    internal class spoofmyhwid
    {
        public static void CheckHWID()
        {
            try
            {
               

                string key = "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\IDConfigDB\\Hardware Profiles\\0001";

                string guid = (string)Registry.GetValue(key, "GUID", (object)"default");

                
                MessageBox.Show("current hwid:" + guid);
            
            }
            catch (Exception)
            {
             

                MessageBox.Show("There was an error while getting your HWID");

               
            }
        }

        public static void SpoofHWID()
        {
            try
            {
                Console.Clear();

                string key = "HKEY_LOCAL_MACHINE\\SYSTEM\\CurrentControlSet\\Control\\IDConfigDB\\Hardware Profiles\\0001";

                string oldHwid = (string)Registry.GetValue(key, "HwProfileGuid", (object)"default");

                string newHwid = "{Spoofer-" + GenID(5) + "-" + GenID(5) + "-" + GenID(4) + "-" + GenID(9) + "}";

                Registry.SetValue(key, "GUID", (object)newHwid);

                Registry.SetValue(key, "HwProfileGuid", (object)newHwid);

                MessageBox.Show("Successfully Changed Your HWID!\n\nOld HWID: " + oldHwid+ "\n\nNew HWID: " + newHwid);

            }
            catch (Exception)
            {

                MessageBox.Show("Failed to change hwid, try to run this as administrator");

                

            }
        }

        private static Random random = new Random();

        public static string GenID(int length)
        {

            string chars = "123457869";
            return new string(Enumerable.Repeat(chars, length).Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}
   
