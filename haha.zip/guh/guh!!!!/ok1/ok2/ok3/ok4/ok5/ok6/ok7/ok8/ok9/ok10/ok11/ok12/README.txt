hi so uhh this shit was made by Bop v4 | 🤨#2956 (id:877655719581745162)

the uhh dont share ur hwid to anyone

you can reset it doe

!!!DONT DELETE THE FILES, OR THE APP WILL NOT WORK!!!